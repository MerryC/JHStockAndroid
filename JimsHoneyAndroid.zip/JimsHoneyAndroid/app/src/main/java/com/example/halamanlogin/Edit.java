package com.example.halamanlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class Edit extends AppCompatActivity {
    Button savebutton;
    Button deletebutton;
    EditText jumlah;
    int nobarang;

    public static final String SHARED_PREF="sharedPreferences";
    public static final String JUMLAH_JAM1= "jmljam1";
    public static final String JUMLAH_JAM2= "jmljam2";
    public static final String JUMLAH_JAM3= "jmljam3";
    public static final String JUMLAH_TAS1= "jmltas1";
    public static final String JUMLAH_TAS2= "jmltas2";
    public static final String JUMLAH_TAS3= "jmltas3";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent intent = getIntent();
        String NamaBrng = intent.getStringExtra("namabarang");
        nobarang = intent.getIntExtra("nobarang",0);

        TextView nama = (TextView) findViewById(R.id.namab);

        nama.setText(NamaBrng);


        savebutton= (Button) findViewById(R.id.save);
        jumlah = (EditText) findViewById(R.id.jml);

        savebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Edit.this,MainActivity.class);
                Toast.makeText(Edit.this, "JUMLAH :"+ jumlah.getText()+" no :"+nobarang , Toast.LENGTH_SHORT).show();
                saveData(nobarang);
                startActivity(intent);
            }
        });

        deletebutton= (Button) findViewById(R.id.hapus);
        deletebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Edit.this,MainActivity.class);
                Toast.makeText(Edit.this, "deleted", Toast.LENGTH_SHORT).show();
                deleteData(nobarang);
                startActivity(intent);
            }
        });
    }
    public void saveData(int no_barang){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if(no_barang==1){
            editor.putString(JUMLAH_JAM1,jumlah.getText().toString());
        }else if(no_barang==2){
            editor.putString(JUMLAH_JAM2,jumlah.getText().toString());
        }else if(no_barang==3){
            editor.putString(JUMLAH_JAM3,jumlah.getText().toString());
        }else if(no_barang==4){
            editor.putString(JUMLAH_TAS1,jumlah.getText().toString());
        }else if(no_barang==5){
            editor.putString(JUMLAH_TAS2,jumlah.getText().toString());
        }else if(no_barang==6){
            editor.putString(JUMLAH_TAS3,jumlah.getText().toString());
        }


        editor.apply();
    }
    public void deleteData(int no_barang){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        if(no_barang==1){
            editor.putString(JUMLAH_JAM1,"0");
        }else if(no_barang==2){
            editor.putString(JUMLAH_JAM2,"0");
        }else if(no_barang==3){
            editor.putString(JUMLAH_JAM3,"0");
        }else if(no_barang==4){
            editor.putString(JUMLAH_TAS1,"0");
        }else if(no_barang==5){
            editor.putString(JUMLAH_TAS2,"0");
        }else if(no_barang==6){
            editor.putString(JUMLAH_TAS3,"0");
        }

        editor.apply();
    }

}
