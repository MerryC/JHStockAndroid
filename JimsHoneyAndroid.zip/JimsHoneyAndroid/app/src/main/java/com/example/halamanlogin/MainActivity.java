package com.example.halamanlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button button1;
    Button button2;
    Button button3;
    Button button4;
    Button button5;
    Button button6;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        button1= (Button) findViewById(R.id.pesan1);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Edit.class);
                intent.putExtra("namabarang","jam 1");
                intent.putExtra("nobarang",1);
                startActivity(intent);
            }
        });

        button2= (Button) findViewById(R.id.pesan2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Edit.class);
                intent.putExtra("namabarang","jam 2");
                intent.putExtra("nobarang",2);
                startActivity(intent);
            }
        });

        button3= (Button) findViewById(R.id.pesan3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Edit.class);
                intent.putExtra("namabarang","jam 3");
                intent.putExtra("nobarang",3);
                startActivity(intent);
            }
        });

        button4= (Button) findViewById(R.id.pesan4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Edit.class);
                intent.putExtra("namabarang","tas 1");
                intent.putExtra("nobarang",4);
                startActivity(intent);
            }
        });
        button5= (Button) findViewById(R.id.pesan5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Edit.class);
                intent.putExtra("namabarang","tas 2");
                intent.putExtra("nobarang",5);
                startActivity(intent);
            }
        });
        button6= (Button) findViewById(R.id.pesan6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,Edit.class);
                intent.putExtra("namabarang","tas 3");
                intent.putExtra("nobarang",6);
                startActivity(intent);
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.optionmenu, menu);
        //getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;

    }

    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId()==R.id.about){
            startActivity(new Intent(this, about.class));
        }  else if (item.getItemId() == R.id.shop) {
            startActivity(new Intent(this, shopchart.class));
        }
        return true;
    }
}
