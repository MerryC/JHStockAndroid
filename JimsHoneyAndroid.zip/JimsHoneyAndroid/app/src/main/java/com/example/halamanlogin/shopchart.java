package com.example.halamanlogin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class shopchart extends AppCompatActivity {
    Button buttonedit1;
    Button buttonedit2;
    Button buttonedit3;
    Button buttonedit4;
    Button buttonedit5;
    Button buttonedit6;
    TextView jmltas1;
    TextView jmltas2;
    TextView jmltas3;
    TextView jmljam1;
    TextView jmljam2;
    TextView jmljam3;
    String jumlah1;
    String jumlah2;
    String jumlah3;
    String jumlah4;
    String jumlah5;
    String jumlah6;

    public static final String SHARED_PREF="sharedPreferences";
    public static final String JUMLAH_JAM1= "jmljam1";
    public static final String JUMLAH_JAM2= "jmljam2";
    public static final String JUMLAH_JAM3= "jmljam3";
    public static final String JUMLAH_TAS1= "jmltas1";
    public static final String JUMLAH_TAS2= "jmltas2";
    public static final String JUMLAH_TAS3= "jmltas3";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopchart);

        jmltas1 = (TextView) findViewById(R.id.jumlahtas1);
        jmltas2 = (TextView) findViewById(R.id.jumlahtas2);
        jmltas3 = (TextView) findViewById(R.id.jumlahtas3);
        jmljam1 = (TextView) findViewById(R.id.jumlahjam1);
        jmljam2 = (TextView) findViewById(R.id.jumlahjam2);
        jmljam3 = (TextView) findViewById(R.id.jumlahjam3);

        loadData();

        jmljam1.setText(jumlah1);
        jmljam2.setText(jumlah2);
        jmljam3.setText(jumlah3);
        jmltas1.setText(jumlah4);
        jmltas2.setText(jumlah5);
        jmltas3.setText(jumlah6);

        buttonedit1= (Button) findViewById(R.id.edit1);

        buttonedit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shopchart.this,Edit.class);
                intent.putExtra("namabarang","jam 1");
                intent.putExtra("nobarang",1);
                startActivity(intent);
            }
        });
        buttonedit2= (Button) findViewById(R.id.edit2);

        buttonedit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shopchart.this,Edit.class);
                intent.putExtra("namabarang","jam 2");
                intent.putExtra("nobarang",2);
                startActivity(intent);
            }
        });

        buttonedit3= (Button) findViewById(R.id.edit3);

        buttonedit3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shopchart.this,Edit.class);
                intent.putExtra("namabarang","jam 3");
                intent.putExtra("nobarang",3);
                startActivity(intent);
            }
        });

        buttonedit4= (Button) findViewById(R.id.edit4);

        buttonedit4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shopchart.this,Edit.class);
                intent.putExtra("namabarang","tas 1");
                intent.putExtra("nobarang",4);
                startActivity(intent);
            }
        });
        buttonedit5= (Button) findViewById(R.id.edit5);

        buttonedit5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shopchart.this,Edit.class);
                intent.putExtra("namabarang","tas 2");
                intent.putExtra("nobarang",5);
                startActivity(intent);
            }
        });
        buttonedit6= (Button) findViewById(R.id.edit6);

        buttonedit6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(shopchart.this,Edit.class);
                intent.putExtra("namabarang","tas 3");
                intent.putExtra("nobarang",6);
                startActivity(intent);
            }
        });
    }
    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences(SHARED_PREF,MODE_PRIVATE);
        jumlah1 = sharedPreferences.getString(JUMLAH_JAM1,"0");

        jumlah2 = sharedPreferences.getString(JUMLAH_JAM2,"0");

        jumlah3 = sharedPreferences.getString(JUMLAH_JAM3,"0");

        jumlah4 = sharedPreferences.getString(JUMLAH_TAS1,"0");

        jumlah5 = sharedPreferences.getString(JUMLAH_TAS2,"0");

        jumlah6 = sharedPreferences.getString(JUMLAH_TAS3,"0");
    }


}
